package com.example.werkws18_18.taschenrechner1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CalcActivity extends AppCompatActivity {

    int A, B;
    EditText edtxt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calc);
        final TextView txt_ergebnis = findViewById(R.id.txt_main);
        Button btn_zero = findViewById(R.id.btn_zero);
        Button btn_one = findViewById(R.id.btn_one);
        Button btn_dez = findViewById(R.id.btn_dezimal);
        Button btn_or = findViewById(R.id.btn_or);
        Button btn_and = findViewById(R.id.btn_and);
        Button btn_xor = findViewById(R.id.btn_xor);
        Button btn_ergebnis = findViewById(R.id.btn_ergebnis);
        edtxt = (EditText) findViewById(R.id.txt_main);

        btn_zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_ergebnis.setText(txt_ergebnis.getText().toString() + "0");
            }
        });
        btn_one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_ergebnis.setText(txt_ergebnis.getText().toString() + "1");
            }
        });

        btn_or.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if (TextUtils.isEmpty(edtxt.getText().toString())) {
                    Toast.makeText(getApplicationContext(),
                            "Bitte Binärzahl eingeben", Toast.LENGTH_LONG).show();
                    edtxt.setText("");
                } else {
                    txt_ergebnis.setText(txt_ergebnis.getText().toString() + "|");
                }
            }
        });
        btn_xor.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if (TextUtils.isEmpty(edtxt.getText().toString())) {
                    Toast.makeText(getApplicationContext(),
                            "Bitte Binärzahl eingeben", Toast.LENGTH_LONG).show();
                    edtxt.setText("");
                } else {
                    txt_ergebnis.setText(txt_ergebnis.getText().toString() + "^");
                }
            }
        });
        btn_and.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if (TextUtils.isEmpty(edtxt.getText().toString())) {
                    Toast.makeText(getApplicationContext(),
                            "Bitte Binärzahl eingeben", Toast.LENGTH_LONG).show();
                    edtxt.setText("");
                } else {
                    txt_ergebnis.setText(txt_ergebnis.getText().toString() + "&");
                }
            }
        });


        btn_dez.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if (TextUtils.isEmpty(edtxt.getText().toString())) {
                    Toast.makeText(getApplicationContext(),
                            "Bitte Binärzahl eingeben", Toast.LENGTH_LONG).show();
                    edtxt.setText("");

                } else {
                    A = Integer.parseInt(edtxt.getText() + "", 2);
                    int dezergebnis = Integer.parseInt(edtxt.getText().toString(), 2);
                    edtxt.setText(Integer.toString(dezergebnis));
                    Toast.makeText(getApplicationContext(),
                            "Ergebnis (Dezimalzahl)", Toast.LENGTH_LONG).show();
                    edtxt.setText("");
                }
            }
        });
    }

}
