package com.example.werkws18_18.taschenrechner1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CalcActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calc);
        final TextView txt_ergebnis = findViewById(R.id.txt_main);
        Button btn_zero = findViewById(R.id.btn_zero);
        Button btn_one = findViewById(R.id.btn_one);

        btn_zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_ergebnis.setText(txt_ergebnis.getText().toString() + "0");
            }
        });
        btn_one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_ergebnis.setText(txt_ergebnis.getText().toString() + "1");
            }
        });
    }

}
